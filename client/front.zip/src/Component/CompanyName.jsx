import React from 'react';

const CompanyName = () => {
  return (
    <div className="text-4xl  text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 animate-gradient edu-nsw-act-cursive">
      Fanloop
    </div>
  );
};

export default CompanyName;
