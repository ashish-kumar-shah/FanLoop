import { createContext } from "react";

const serviceContext = createContext()
export default serviceContext