import { createContext } from "react";

  const PostContext = createContext()

  export default PostContext;